var app = angular.module('ponudjac.controllers', []);
 
app.controller('ponudjacController', ['$scope','$window','ponudjacService', '$location',
  	function ($scope,$window, ponudjacService, $location) {
		
		$scope.getLoggedUser = function() {
			ponudjacService.getLoggedUser().then(
				function (response) {
					$scope.loggedUser = response.data;
					sveObjave2();
	            }	
				
				
			);
			
		}
		
		$scope.update = function() {
			ponudjacService.updatePonudjacProfile($scope.loggedUser).then(
				function (response) {
                    $scope.state = undefined;
                    $location.path('/ponudjac/profili');
				}
			);
		}
		
		
		$scope.sveObjave = function() {
			ponudjacService.sveObjavee($scope.loggedUser).then(
				function (response) {
                    $scope.list = response.data;
                    
				}
			);
		
		}

		$scope.posaljiPonudu = function() {
			ponudjacService.ponuda(porudzba,$scope.loggedUser,$scope.garancija,$scope.cena,$scope.isporuka).then(
				function (response) {
                   
					 $location.path('/ponudjac/profili');
				}
			);
		
		}
		
		function sveObjave2(){
			ponudjacService.sveObjavee($scope.loggedUser).then(
					function (response) {
	                    $scope.list = response.data;
	                    
					}
				);
		}
}]);
