package restoran.enumeracije;

public enum Smena {
	First, Second;
}
