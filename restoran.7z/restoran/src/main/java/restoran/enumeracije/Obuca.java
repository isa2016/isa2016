package restoran.enumeracije;

public enum Obuca {
	br36, br37, br38, br39, br40, br41, br42, br43, br44, br45, br46;
}
