package restoran.enumeracije;

public enum PiceStatus {
	ORDERED, ONHOLD, FINISHED;
}
