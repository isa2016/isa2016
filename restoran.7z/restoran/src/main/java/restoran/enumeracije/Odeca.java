package restoran.enumeracije;

public enum Odeca {
	S, M, L, XL, XXL;
}
