package restoran.enumeracije;

public enum HranaStatus {
	ORDERED, ONHOLD, PREPARATION, FINISHED;
}
