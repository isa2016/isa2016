package restoran.kontroleri;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import restoran.model.ObjavaPonude;
import restoran.model.PonudaP;
import restoran.model.Restoran;
import restoran.model.osoba.MenadzerRestorana;
import restoran.model.osoba.Ponudjac;
import restoran.servis.MenadzerRestoranaServis;
import restoran.servis.PonudjacServis;
import restoran.servis.RestoranServis;


@RestController
@RequestMapping("/ponudjac")
public class PonudjacController {


	private final PonudjacServis ponudjacServis;
	private HttpSession httpSession;
    private RestoranServis restoranServis;   
    private final MenadzerRestoranaServis mrServis;
	
	@Autowired
	public PonudjacController(final HttpSession httpSession, final PonudjacServis servis, final RestoranServis restServis,final MenadzerRestoranaServis mRServis) {
		this.ponudjacServis = servis;
		this.httpSession = httpSession;
		this.restoranServis = restServis;	
		this.mrServis = mRServis;
	}
     
	
	@PutMapping(path = "/ponudjacUpdate/{id}")
	@ResponseStatus(HttpStatus.OK)
	public Ponudjac update(@PathVariable Long id, @Valid @RequestBody Ponudjac ponudjac) {
	 	
		System.out.println("AJDEEEEEEEEEEEEEEEEEEE");
		Optional.ofNullable(ponudjacServis.findOne(id))
				.orElseThrow(() -> new ResourceNotFoundException("Resource Not Found!"));
		ponudjac.setId(id);
		httpSession.setAttribute("korisnik", ponudjac);
		return ponudjacServis.save(ponudjac);
	
	}
	
	@GetMapping("/ponudjacObjave/{id}")
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<List<ObjavaPonude>> sveObjave(@PathVariable Long id) {
	    System.out.println("Ponudjaciiiiiiiiiiiiiii");
		Ponudjac p = ponudjacServis.findOne(id);
	    List<ObjavaPonude> op = p.getObjave();
	
	    return new ResponseEntity<>(op, HttpStatus.OK);
	}
	
	@PutMapping(path = "/ponudjacPonuda/{id}/{id2}/{cena}/{garancija}/{isporuka}")
	@ResponseStatus(HttpStatus.OK)
	public void posaljiPonudu(@PathVariable Long id,@PathVariable Long id2,@PathVariable String cena,@PathVariable String garancija,@PathVariable String isporuka) {
	 	
		Ponudjac p = ponudjacServis.findOne(id2);
		double ce = Integer.parseInt(cena);
		int gara = Integer.parseInt(garancija);
		
		Restoran r = restoranServis.findOne(id);
		
		PonudaP pp = new PonudaP();
		
		pp.setPonudjac_Id(id2);
		pp.setCena(ce);
		pp.setGarancija(gara);
		pp.setRokIsporuke(isporuka);
		
		List<MenadzerRestorana> mr = r.getMenadzeriRestorana();
		
		MenadzerRestorana m = null;
		
		for(int i=0;i<mr.size();i++){
			if(id.equals(mr.get(i).getRestoranId())){
				m = mr.get(i);
			}
		}
		
	   m.getPonudaP().add(pp);
	   mrServis.save(m);
	}
}
